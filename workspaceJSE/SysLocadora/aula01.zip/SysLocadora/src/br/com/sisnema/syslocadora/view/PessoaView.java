package br.com.sisnema.syslocadora.view;

public class PessoaView {

	public static void run() {
		// TODO Auto-generated method stub
		
	}

}
